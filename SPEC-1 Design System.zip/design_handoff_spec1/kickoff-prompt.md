# Kickoff prompt — paste into Claude Code

Copy everything below the line into Claude Code once you're in the target repo (with this
handoff folder available). Adjust the framework line if your repo already has a stack.

---

I'm implementing the **SPEC-1 Intelligence Engine** UI in this repo. The design spec and
reference kits are in `design_handoff_spec1/`. Read these first, in order:

1. `design_handoff_spec1/README.md` — the full handoff spec (per-screen anatomy, tokens, behavior)
2. `design_handoff_spec1/CLAUDE.md` — the non-negotiable design rules
3. `design_handoff_spec1/design-source/colors_and_type.css` — authoritative design tokens
4. `design_handoff_spec1/design-source/ui_kits/console/` — the primary surface (open `index.html`)

Then:

- Tell me what framework/stack this repo uses (or, if there's no UI yet, recommend one and why).
- Port `colors_and_type.css` into this repo's theme layer as the single token source — no inline hexes.
- Scaffold the **console app shell**: fixed 52px header, 210px left sidebar, 900px-max scrolling
  content column, Flower-of-Life background at 5% opacity.
- Then build the panels one at a time, starting with **Daily Brief** and the **Intel Records**
  table, matching the README spec exactly (monochrome, 1px hairlines, zero radius, no shadow,
  monospace, Unicode glyph icons).
- Stub data with the shapes in each kit's `data.js`; leave a clear seam for real data fetching.

Do **not** copy the HTML/Babel setup — it's a prototype. Recreate the designs in this repo's
own patterns. Confirm the stack and your plan before writing component code.
