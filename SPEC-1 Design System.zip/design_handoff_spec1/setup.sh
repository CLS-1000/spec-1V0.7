#!/usr/bin/env bash
# ============================================================================
# SPEC-1 — prepare a Claude Code working session
# Scaffolds a working folder, installs CLAUDE.md + the design tokens, and
# prints the next step. Safe to re-run (idempotent).
#
#   Usage:  bash design_handoff_spec1/setup.sh [target-dir]
#   Default target-dir: ./spec1-app
# ============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-spec1-app}"

echo "── SPEC-1 :: prepare Claude Code ───────────────────────────────"
echo ">> source : $HERE"
echo ">> target : $TARGET"

mkdir -p "$TARGET/design"

# 1. Drop CLAUDE.md at the target root so Claude Code auto-loads the rules.
cp "$HERE/CLAUDE.md" "$TARGET/CLAUDE.md"
echo "[OK] CLAUDE.md installed at target root"

# 2. Bring the authoritative tokens + reference kits alongside.
cp "$HERE/README.md"            "$TARGET/design/HANDOFF.md"
cp "$HERE/kickoff-prompt.md"    "$TARGET/design/kickoff-prompt.md"
cp -R "$HERE/design-source"     "$TARGET/design/design-source"
echo "[OK] design spec + tokens + reference kits copied to $TARGET/design/"

# 3. Seed a tokens file in a conventional place if the repo wants one.
mkdir -p "$TARGET/src/styles" 2>/dev/null || true
cp "$HERE/design-source/colors_and_type.css" "$TARGET/src/styles/spec1-tokens.css" 2>/dev/null || true
echo "[OK] tokens seeded at $TARGET/src/styles/spec1-tokens.css"

cat <<'NEXT'

── READY ───────────────────────────────────────────────────────
Next steps:
  1. cd into the target dir and open it in Claude Code.
  2. Paste design/kickoff-prompt.md as your first message.
  3. Confirm the framework, then build panel-by-panel against design/HANDOFF.md.

  // CLASSIFICATION: UNCLASSIFIED · SPEC-1 // EVASTARARCANA
NEXT
