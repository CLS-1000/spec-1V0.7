# CLAUDE.md — SPEC-1 Intelligence Engine

> Drop this file at the root of the target repo. Claude Code reads it automatically and will
> hold the SPEC-1 design language on every change. Pair it with `design-source/` (the HTML
> reference kits + `colors_and_type.css`).

## What you're building

SPEC-1 — an automated OSINT signal-monitoring product. The UI is a **classified terminal
crossed with a printed classified document.** See `README.md` (the full handoff spec) and
`design-source/DESIGN_SYSTEM.md` for product context, voice, and iconography.

## The design system is the source of truth

`design-source/colors_and_type.css` holds the authoritative tokens. **Copy them into this
repo's theme layer verbatim** and reference tokens — never hardcode hexes inline.

## Non-negotiable rules

- **Monochrome.** Black `#000` canvas, `#0A0A0A` surfaces. Hierarchy = white opacity ramp
  (`#FFF → #CCC → #666`). Severity = **brightness, not hue**. The only hues are
  `--signal-pass #00FF00` and `--signal-alert #FF0000`, used **only** for live status.
- **Square.** `border-radius: 0` everywhere. Every border is a **1px white hairline**
  (`rgba(255,255,255,.20–.30)`); emphasis = 2px.
- **No `box-shadow`. Ever.** Depth = border + surface darkness only.
- **Monospace only.** `IBM Plex Mono` (interface) + `Courier Prime` (IDs/code/data). Hierarchy
  from weight + UPPERCASE + letter-spacing, not size.
- **Icons = Unicode glyphs** in the mono face (`◈ ◻ ⊹ ▣ ⊗ ⊡ ▷ ▸ ●`). No emoji, no icon fonts,
  no drawn/multicolor SVGs. Thin-stroke line icons only as a flagged last resort.
- **Flower of Life** pattern at 5% opacity behind dark surfaces — lift the `<pattern>` verbatim
  from any kit's `index.html`, never redraw.
- **Motion is mechanical:** blinking block cursor, 0.8s linear spinner, `.12–.15s` hover.
  No fades/slides/bounces/parallax. Ease `cubic-bezier(.4,0,.2,1)`.

## Voice

Sober, precise, declarative — terminal operator meets intelligence analyst. Short sentences,
present tense, no hype, no exclamation, no emoji. UPPERCASE+tracking for labels; `[BRACKET]`
tokens for system entities; `code` for machine-addressable things; numbers cited flatly as
proof. Status words: `PASS · CAUTION · ONLINE/OFFLINE · STABLE · READY · [OK]`.

## How to work

1. These HTML files are **design references, not code to copy.** Recreate them in THIS repo's
   framework and patterns. If the repo has no UI yet, pick the best-fit framework and say so.
2. Start from the tokens, then build the app shell (52px header · 210px sidebar · 900px content
   column), then panels one at a time against `README.md`'s per-screen spec.
3. Replace the prototypes' in-file `data.js` fixtures with real data fetching — but keep the
   data shapes; they're a faithful API contract.
4. When unsure about a value, read the matching `ui_kits/*/styles.css` — it's lifted from the
   real product source.
