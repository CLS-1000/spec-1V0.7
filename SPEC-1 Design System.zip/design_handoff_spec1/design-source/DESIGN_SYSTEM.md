# SPEC-1 Intelligence Engine — Design System

> Automated OSINT for national-security signal monitoring.
> `// v0.6.0 · Portland OR · EVASTARARCANA`

This is the design system for **SPEC-1**, a classified-terminal aesthetic intelligence
console. Everything here exists so a design agent can generate well-branded SPEC-1
interfaces, marketing pages, briefs, and mockups that look like they shipped from the
real product.

---

## 1. What SPEC-1 is

SPEC-1 is an **automated open-source-intelligence (OSINT) engine** for national-security
signal monitoring, built by **EVASTARARCANA LLC** (Portland, OR). Its thesis is one line:

> **The bottleneck is attention, not access.**

Authoritative reporting is abundant; analyst hours are not. SPEC-1 monitors a curated set
of high-credibility sources continuously, scores every incoming signal through a
**four-gate deterministic filter** (Credibility · Volume · Velocity · Novelty), and hands
only the survivors to Claude for investigation and verification. What reaches the analyst
is already classified, scored, and structured — *a decision, not a digest.*

**The system handles the volume. The analyst handles the judgment.**

### The pipeline (the spine of all the product copy)
```
[01 HARVEST] > [02 PARSE] > [03 SCORE] > [04 INVESTIGATE] > [05 VERIFY] > [06 ANALYZE] > [07 STORE]
```
Seven sequential, independently fault-tolerant stages. A dead RSS feed never halts the
06:00 cron. Signals that clear all four gates become `Opportunity` objects → investigated
→ verified by Claude → synthesized into `IntelligenceRecord` objects → dual-written to
append-only JSONL (ground truth) + SQLite (query layer).

### Surfaces / products represented in this system
| Surface | Source file | What it is | UI kit |
|---|---|---|---|
| **Console** | `spec1_ui.html` | The analyst dashboard app — sidebar nav, daily brief, signals/intel tables, leads, psyop, FARA, cycle, verdicts, calibration | `ui_kits/console/` |
| **Web** | `spec1_portfolio.html`, `index.html` | Marketing / portfolio site + terminal landing — hero, pipeline diagrams, gate grids, tech tables | `ui_kits/web/` |
| **Brief** | `assets/brief_style.css` | The published intelligence brief — *inverted* (black on white), masthead, justified columns. Documented in Visual Foundations. | — |
| Political Web | `spec1_political_web.html` | A D3 force-directed network graph of FARA/congressional relationships (noted, not kitted) | — |

### Sources (for the reader — you may not have access)
- **GitHub:** <https://github.com/mjlak1000/spec-1> — the canonical source of truth.
  Explore it to do a better job: `spec1_ui.html` (console), `spec1_portfolio.html`
  (marketing), `index.html` (landing), `assets/brief_style.css` (brief), `docs/portfolio.md`,
  `README.md`, `INVESTOR_PITCH.md`, `OUTREACH_TEMPLATES.md` (voice & copy).
- **Live:** landing `mjlak1000.github.io/spec-1` · dashboard `/spec-1/ui/`
- Imported into this project: `assets/spec1_social_card.png` (the official brand card).

---

## 2. CONTENT FUNDAMENTALS — how SPEC-1 writes

The voice is **terminal operator meets intelligence analyst.** Sober, precise, declarative.
It never sells; it reports. If a sentence could appear in a marketing deck *and* a
classified memo, it's on-brand.

**Tone & vibe**
- **Declarative and compressed.** Short sentences. No hedging, no hype, no exclamation.
  "The system handles the volume. The analyst handles the judgment."
- **Operational, not aspirational.** Talks about what the system *does*, in present tense,
  mechanically. "Any single failure drops the signal to `/dev/null`."
- **Confident restraint.** Mentions that certain parameters (gate weights, thresholds,
  source ratings) are *deliberately unpublished* — "Gate weights remain unpublished." The
  redaction *is* the brand.

**Person & address**
- Third-person about the system ("SPEC-1 monitors…", "The harvester handles…").
- Second-person sparingly, in impact statements: "You start your day with filtered signal."
- First-person plural is essentially absent. No "we believe."

**Casing & typography of copy**
- **UPPERCASE + letter-spacing** for labels, statuses, nav sections, stage names:
  `RAW SIGNALS`, `CREDIBILITY GATE`, `CLASSIFICATION: UNCLASSIFIED`.
- **Bracket-tagged tokens** for named modules and domains: `[CREDIBILITY]`, `[FARA]`,
  `[ cls_world_brief ]`, `[01 HARVEST]`. Brackets = "this is a system entity."
- **`code`-style** for anything machine-addressable: `IntelligenceRecord`, `make brief`,
  `cls_db.dual_write`, `record_id`.
- **`//` and `>>` prefixes** for log/aside lines: `// v0.6.0 · Portland OR`,
  `>> SYSTEM METADATA LOG`. **`$`** prefix for shell/section headers: `$ pipeline::stages`.
- **`::`** as a namespace separator in UI titles: `SPEC-1 :: OSINT SIGNAL ENGINE`.

**Vocabulary** — signal, noise, triage, harvest, gate, opportunity, investigate, verify,
corroborated, escalate, monitor, archive, confidence, calibration, drift, verdict, ground
truth, adapter, registrant, narrative, astroturfing, psyop. Status words: `PASS`,
`CAUTION`, `ONLINE`/`OFFLINE`, `STABLE`, `READY`, `[OK]`.

**Numbers as proof.** Counts are cited flatly as credibility: "607 tests," "1,359 tests
passing across 37+ files," "7-stage pipeline," "40% over 18 months." Never dramatized.

**Emoji:** none in the product UI. (The repo's contributor cards use 📦/✓ once; treat that
as off-system — **do not use emoji** in SPEC-1 interfaces. Use the glyph set below instead.)

**Micro-examples**
- Eyebrow: `PORTFOLIO SUMMARY` · Hero: `Open Source Intelligence Engine`
- Status line: `● PIPELINE ACTIVE  ●  LAST HARVEST: 2026-05-28 04:23:17 UTC`
- Assessment: `OBSERVATION :: Legislative-commercial timeline compression has accelerated by 40%.`
- Footer: `SPEC-1 // EVASTARARCANA · Portland OR — CLASSIFICATION: UNCLASSIFIED`

---

## 3. VISUAL FOUNDATIONS

The system reads as a **CRT terminal crossed with a printed classified document.** It is
ruthlessly monochrome and ruthlessly square.

**Color.** Pure black canvas (`#000`), near-black surfaces (`#0A0A0A`). Hierarchy is built
almost entirely from a **white-on-black opacity ramp** — `#FFF → #CCC → #666` for text;
`rgba(255,255,255,.30 / .20 / .12 / .06)` for borders and dividers. The *only* hues are two
signal accents used strictly for live status: **green `#00FF00`** (PASS / ONLINE /
CORROBORATED) and **red `#FF0000`** (CAUTION / spike). Form errors use a softened red.
There are **no gradients, no brand blue/purple, no color-coded categories** — severity is
encoded by *brightness*, not hue (critical = full white, archive = 10% white).

**Type.** Two monospaces, nothing else. **IBM Plex Mono** is the interface face (everything
you read); **Courier Prime** is the "machine output" face for IDs, code, timestamps, raw
data. The scale is **compact and dense** — panel titles 20px, body 13px, UI 12px, labels
10px. Hierarchy comes from **weight, UPPERCASE, and letter-spacing**, not size. Tracking is
a signature: the more official the label, the wider it's tracked (`.10em`–`.18em`).

**Backgrounds.** Every dark surface carries the **Flower of Life** SVG pattern — interlocking
circles tiled at **5% opacity** behind the content (`#fol-bg`, fixed, pointer-events:none).
It's the one ornamental motif; it reads as a faint sacred-geometry watermark. Surfaces sit
on top at `rgba(10,10,10,.92–.96)` so the pattern only whispers through. No photography in
the dark UI.

**Borders & shape.** **Border-radius is 0 everywhere** — corners are corners. Everything is
a **1px white hairline** (`rgba(255,255,255,.2–.3)`); emphasis frames (the brief masthead)
go to 2px solid. The masthead adds **corner ticks** (20px L-brackets at opposite corners) —
a printed-dossier detail. Grids are drawn by 1px gaps over a white background bleeding
through (`gate-grid`, `outcome-list`).

**Shadows & depth.** **None.** No `box-shadow` anywhere. Depth = border + surface darkness
only. Do not add drop shadows; it breaks the flat-terminal read.

**Cards.** A card is a bordered rectangle on `rgba(10,10,10,.9)` — 1px hairline, sharp
corners, generous internal padding (16–24px), no rounding, no shadow. Hover lifts the border
to full/brighter white and adds a `rgba(255,255,255,.03–.04)` wash. That's the entire card
language.

**Hover / press / focus.**
- *Hover:* border brightens toward white and/or a faint white wash appears; muted text
  brightens to secondary/primary. Transitions `.12s`.
- *Inputs focus:* border goes from `.3` → full white (`border-color: #fff`). No glow, no ring.
- *Buttons:* ghost by default (transparent, 1px border, mono caps). Hover = subtle white
  wash (`rgba(255,255,255,.06)`) or full invert (white bg / black text) on the landing CTA.
- *Press:* color/inversion only — **no scale, no bounce.**

**Status indicators.** A **diamond** — an 8px square rotated 45° with a 1px border; filled
white = online, hollow = offline. Bullets `●` for active states. Confidence shown as a thin
3px track with a solid white fill bar + a Courier value (`0.82`).

**Badges.** 10px uppercase, 1px border, no fill. Severity scales the border/text opacity:
critical/corroborated = full white, high = .70, medium = .45, low/clean = .20, archive = .10.

**Motion.** Minimal and mechanical. A **blinking block cursor** (`step-end`, 1s). A 0.8s
linear **spinner** (1px ring, white top). Bar fills and the status dot transition `.3s`.
Everything else is a `.12–.15s` ease on hover. **No fades-in, no slides, no bounces, no
parallax.** Standard ease `cubic-bezier(.4,0,.2,1)`.

**Transparency & blur.** Transparency yes (surfaces are `rgba` so the Flower-of-Life shows
through; sticky headers are `rgba(0,0,0,.94–.96)`). **Blur: none** — no backdrop-filter, no
frosted glass. The look is hard-edged, not glassy.

**Layout.** Fixed 52px top bar (sticky, hairline bottom). 210px left sidebar in the console.
Content maxes at ~900px in the marketing/brief reading column. Dense tables with 10px
uppercase headers. Generous vertical rhythm between sections, divided by `.12` hairlines.

**The Brief is the one inversion.** The *published* intelligence brief
(`assets/brief_style.css`) flips to **black ink on white paper** — a printed broadsheet:
2px black masthead with corner ticks, 6px letter-spaced 40px title, justified 12px columns,
`▸`-bulleted lists, hairline `<hr>` rules. Everything else in the system is dark; the brief
is the artifact that "prints."

---

## 4. ICONOGRAPHY

SPEC-1 has **no icon font and no SVG icon set.** Iconography is **Unicode geometric glyphs**
rendered in the monospace face — sharp, abstract, terminal-native. This is deliberate: glyphs
sit on the monospace baseline and need no assets.

**The glyph vocabulary** (lifted from the console sidebar & system):
| Glyph | Used for | | Glyph | Used for |
|---|---|---|---|---|
| `◈` | Brief · Leads (primary) | | `⊗` | Psyop |
| `◻` | Archive · Verdicts | | `⊡` | FARA |
| `⊹` | Raw Signals | | `▷` | Cycle · Local Access (run) |
| `▣` | Intel Records | | `⊞` | Calibration |
| `▸` | list bullets / lead actions | | `●` | active / live status |
| `◆`/45° square | status diamond (online/offline) | | `$ :: // >>` | shell / namespace / log prefixes |

**Rules**
- Render glyphs in `--font-mono`, same color ramp as text (muted by default, white when active).
- **No emoji.** **No multicolor icons.** **No drawn SVG icons.** If you genuinely need a
  pictographic icon the glyph set can't cover, use a **thin-stroke monochrome line set
  (Lucide / Phosphor "thin")** at 1–1.25px stroke, white-on-black, and **flag the
  substitution** — it is not native to the product.

**Logo / brand mark.** Purely typographic, no image file required:
- **Wordmark:** `[ SPEC-1 INTELLIGENCE ENGINE ]` — bold IBM Plex Mono caps, wrapped in
  literal square brackets with spaces inside the brackets. See `assets/spec1_social_card.png`.
- **Badge / favicon mark:** `S1` in a 1px bordered box, 10px bold, `.14em` tracking — used at
  small sizes in the app header next to the wordmark.
- **Lockup variants:** wordmark over the terminal boot block (`INIT PID 1…`) for hero/social;
  badge + "SPEC-1 Intelligence Engine" for app chrome.

**The Flower of Life** is the only non-type brand graphic — the tiled circle pattern behind
dark surfaces (see Visual Foundations). Reuse the exact SVG `<pattern>` from any source file
at 5% opacity; do not redraw it freehand.

---

## 5. Index — files in this system

**Root foundations**
| File | What it is |
|---|---|
| `README.md` | This file — product context, content + visual foundations, iconography |
| `colors_and_type.css` | All design tokens — color ramp, signal accents, type scale, tracking, geometry, spacing, motion. Base + semantic (`.s1` scope). |
| `SKILL.md` | Agent-Skill manifest (for use in Claude Code) |
| `assets/` | `spec1_social_card.png` (brand card), `brief_style.css` reference |

**Design System cards** — `preview/` (21 cards, shown in the Design System tab)
- Colors: core palette · text ramp · border/divider ramp · signal accents · severity ramp
- Type: font families · type scale · tracking & casing
- Spacing: geometry (radius/borders/shadow) · spacing scale · dossier frame
- Components: buttons · badges · form inputs · data table · status & confidence · card · sidebar nav
- Brand: logo lockups · Flower of Life · boot block

**UI Kits** — `ui_kits/`
| Kit | Surface | Entry |
|---|---|---|
| `console/` | Analyst dashboard app (brief, signals, intel, leads, psyop, FARA, cycle) | `index.html` |
| `web/` | Marketing / portfolio site (hero, pipeline, gate grid, adapters, tech) | `index.html` |
| `political/` | Political Intelligence (PDX-1i): **Overview explainer · Metro District Map · 3D Web Map** · Signal Feed · Statistics | `index.html` |

Each kit has its own `README.md`, `styles.css` (lifted from the real source for fidelity),
and factored component/data files.

---

*Built from the SPEC-1 source: <https://github.com/mjlak1000/spec-1>. Explore that
repository — especially `spec1_ui.html`, `spec1_portfolio.html`, `spec1_political_web.html`,
and `docs/portfolio.md` — to build higher-fidelity SPEC-1 designs.*
