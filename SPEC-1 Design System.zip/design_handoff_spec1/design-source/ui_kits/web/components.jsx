/* SPEC-1 Web — marketing/portfolio components, exported to window.S1W */
const { useState } = React;

function Header() {
  return (
    <header>
      <div className="logo"><span className="logo-badge">S1</span>SPEC-1 Intelligence Engine</div>
      <div className="header-meta">
        <a href="#architecture">Architecture</a>
        <a href="#adapters">Adapters</a>
        <a href="#stack">Stack</a>
        <span>v0.6.0</span>
      </div>
    </header>
  );
}

function BootBar() {
  return (
    <div className="boot">
      <div className="boot-box">
        INIT PID 1...<br />
        PYTHON 3.11+ DETECTED<br />
        LOADING 1,359 TESTS... <span className="pass">[OK]</span><br />
        PIPELINE STATUS: READY<br />
        <span className="muted">$ ./spec1 --mode harvest --source all</span><span className="cursor" />
      </div>
    </div>
  );
}

function Hero() {
  return (
    <div className="hero">
      <div className="hero-eyebrow">Portfolio Summary · EVASTARARCANA · Portland OR</div>
      <div className="hero-title">Open Source Intelligence Engine</div>
      <div className="hero-sub">Signal → Opportunity → Investigation → Intelligence</div>
      <div className="badges">
        <div className="badge"><strong>1,359</strong> Tests</div>
        <div className="badge"><strong>7</strong>-Stage Pipeline</div>
        <div className="badge">Python <strong>3.11+</strong></div>
        <div className="badge">Claude <strong>API</strong></div>
        <div className="badge">v<strong>0.6.0</strong></div>
      </div>
      <div className="cta-row">
        <button className="btn btn-solid" onClick={() => document.getElementById('architecture').scrollIntoView({ behavior: 'smooth' })}>Read the architecture</button>
        <button className="btn" onClick={() => document.getElementById('stack').scrollIntoView({ behavior: 'smooth' })}>Technical summary</button>
      </div>
    </div>
  );
}

const STAGES = [
  ['01', 'Harvest'], ['02', 'Parse'], ['03', 'Score'], ['04', 'Investigate'], ['05', 'Verify'], ['06', 'Analyze'], ['07', 'Store'],
];

function Pipeline() {
  return (
    <div className="pipeline">
      <div className="pipeline-label">Pipeline — seven stages · Harvest → Store</div>
      <div className="pipeline-row">
        {STAGES.map(([n, name]) => (
          <div className="p-stage" key={n}><div className="p-stage-num">{n}</div><div className="p-stage-name">{name}</div></div>
        ))}
      </div>
    </div>
  );
}

const GATES = [
  ['Gate 1', 'Credibility', 'Source rating · Editorial standard · Domain track record'],
  ['Gate 2', 'Volume', 'Content depth · Word threshold · Substance filter'],
  ['Gate 3', 'Velocity', 'Recency score · Time-window decay · Sliding scale'],
  ['Gate 4', 'Novelty', 'Keyword taxonomy · Domain relevance · Subject filter'],
];

function GateGrid() {
  return (
    <div className="pipeline">
      <div className="pipeline-label">Stage 03 exploded — Four-gate framework · Any single failure → signal dropped</div>
      <div className="gate-grid">
        {GATES.map(([num, name, detail]) => (
          <div className="gate-cell" key={name}>
            <div className="gate-num">{num}</div>
            <div className="gate-name">{name}</div>
            <div className="gate-detail">{detail}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

const OUTCOMES = [
  ['Corroborated', 'Evidence supports the hypothesis'],
  ['Escalate', 'High-confidence, high-urgency finding'],
  ['Investigate', 'Hypothesis plausible, more research needed'],
  ['Monitor', 'Signal is real but not yet actionable'],
  ['Conflicted', 'Evidence is contradictory'],
  ['Archive', 'Signal does not warrant further attention'],
];

function Outcomes() {
  return (
    <div className="pipeline">
      <div className="pipeline-label">Stage 05 exploded — Verification outcomes · Claude Haiku · + confidence score</div>
      <div className="outcome-list">
        {OUTCOMES.map(([name, desc]) => (
          <div className="outcome-row" key={name}><div className="outcome-name">{name}</div><div className="outcome-desc">{desc}</div></div>
        ))}
      </div>
    </div>
  );
}

const ADAPTERS = [
  ['cls_osint/adapters/fara', 'FARA bulk filing ingestion. Cross-references foreign agent registrations against congressional activity and known influence networks.', '22 tests'],
  ['cls_osint/adapters/congressional', 'Congressional trade intelligence via a fallback chain: Quiver Quantitative → Capitol Trades → House eFD. Flags defense, cyber, and energy trades.', '35 tests'],
  ['cls_osint/adapters/narrative', 'Psychological-operations detection. TF-IDF cosine clustering surfaces narrative seeding, astroturfing, and source discrediting as scored signals.', ''],
  ['cls_db.dual_write', 'Atomic dual-write layer. JSONL is the immutable ground truth; SQLite is the query layer for historical analysis.', ''],
];

function Adapters() {
  return (
    <div className="adapter-stack">
      {ADAPTERS.map(([name, desc, tests]) => (
        <div className="adapter-row" key={name}>
          <div className="adapter-name">{name}</div>
          <div className="adapter-desc">{desc}</div>
          {tests && <div className="adapter-tests">{tests}</div>}
        </div>
      ))}
    </div>
  );
}

const TECH = [
  ['Language', 'Python 3.9–3.12'],
  ['Pipeline stages', '7 — [01] Harvest → [07] Store'],
  ['Scoring', '4-gate deterministic filter — credibility, volume, velocity, novelty'],
  ['AI integration', 'Claude Haiku (verification) · Claude Sonnet (briefing) · rule-based fallback'],
  ['Market signals', '4-sector equity watchlist via yfinance'],
  ['Persistence', 'Append-only JSONL (source of truth) · SQLite dual-write (query layer)'],
  ['Operations', 'FastAPI + APScheduler · 06:00 AM PT daily cron · MCP tools for Claude'],
  ['Tests', '1,359 passing across 37+ files'],
  ['Architecture version', 'v0.6.0'],
];

function TechTable() {
  return (
    <table className="tech-table">
      <tbody>{TECH.map(([k, v]) => <tr key={k}><td>{k}</td><td>{v}</td></tr>)}</tbody>
    </table>
  );
}

function Section({ num, title, children }) {
  return (
    <div className="section" id={num.includes('Architecture') ? 'architecture' : undefined}>
      <div className="section-num">{num}</div>
      <div className="section-title">{title}</div>
      {children}
    </div>
  );
}

function Footer() {
  return (
    <footer>
      <span>SPEC-1 · EVASTARARCANA · Portland OR</span>
      <span>CLASSIFICATION: UNCLASSIFIED · v0.6.0</span>
    </footer>
  );
}

Object.assign(window, {
  S1W: { Header, BootBar, Hero, Pipeline, GateGrid, Outcomes, Adapters, TechTable, Section, Footer },
});
