/* SPEC-1 Console — fake intelligence data (demo) */
window.S1_DATA = {
  stats: { signals: 1284, intel: 47, leads: 12, briefs: 28, online: true, version: '0.6.0' },

  brief: {
    date: '2026-05-28', confidence: 0.88, brief_id: 'brief_2026_0528_06',
    produced: '2026-05-28 06:04 PT',
    headline: 'Disclosure-timing compression accelerates across dual-jurisdiction committees',
    summary: 'Three corroborated signals this cycle converge on a single pattern: the interval between committee markup and public announcement continues to compress for members holding joint finance-and-technology jurisdiction. Baseline expectation is 14–21 days; the current cycle average is **8–12 days**, with two outliers under 7.',
    sections: [
      { title: 'Elevated', body: '**[ESCALATE]** A `[CONGRESSIONAL]` adapter flag cross-referenced a defense-sector equity disclosure against a closed-door markup 6 days prior. Source weight 0.81, corroborated against two independent filings. Recommend monitoring disclosure deltas under 7 days for the relevant subcommittee.' },
      { title: 'Cyber', body: 'Narrative-cluster detection surfaced coordinated language across four tracked outlets describing an unattributed infrastructure intrusion. TF-IDF cosine similarity 0.79 — above the seeding threshold. Classified **MONITOR** pending a second corroborating source.' },
      { title: 'Watch List', body: '- FARA registrant–principal relationship pending re-verification (filing amended 2026-05-26)\n- Energy-major volume anomaly, 2.4× relative — no textual signal yet\n- Metro Council President vacancy: appointment deadline 2026-06-11' },
    ],
    sources: ['warontherocks.com', 'justsecurity.org', 'cipherbrief.com'],
  },

  archive: [
    { date: '2026-05-28', headline: 'Disclosure-timing compression accelerates across dual-jurisdiction committees', words: 412, conf: 0.88, id: 'brief_2026_0528_06' },
    { date: '2026-05-27', headline: 'Energy-sector volume anomaly precedes regional grid advisory by 36 hours', words: 388, conf: 0.74, id: 'brief_2026_0527_06' },
    { date: '2026-05-26', headline: 'Narrative seeding detected across four tracked outlets; campaign aggregation pending', words: 451, conf: 0.69, id: 'brief_2026_0526_06' },
    { date: '2026-05-25', headline: 'FARA amendment surfaces undisclosed principal in defense-adjacent network', words: 401, conf: 0.82, id: 'brief_2026_0525_06' },
    { date: '2026-05-24', headline: 'Quiet cycle — three signals cleared gates, none escalated', words: 296, conf: 0.55, id: 'brief_2026_0524_06' },
  ],

  signals: [
    { id: 'sig_8f2a91', source: 'War on the Rocks', type: 'RSS', text: 'Analysis: timeline compression in defense procurement disclosure', pub: '2026-05-28 04:23' },
    { id: 'sig_2c1d77', source: 'DOJ FARA', type: 'FARA', text: 'Amended registration — principal relationship updated', pub: '2026-05-28 03:11' },
    { id: 'sig_9b40e2', source: 'Capitol Trades', type: 'CONGRESSIONAL', text: 'Member disclosure: defense prime, 6 days post-markup', pub: '2026-05-28 02:50' },
    { id: 'sig_4a17c0', source: 'Just Security', type: 'RSS', text: 'Infrastructure intrusion reporting — attribution withheld', pub: '2026-05-28 01:38' },
    { id: 'sig_1e93ba', source: 'Narrative Monitor', type: 'NARRATIVE', text: 'Coordinated language cluster across 4 outlets, sim 0.79', pub: '2026-05-27 23:02' },
    { id: 'sig_7d50ff', source: 'Atlantic Council', type: 'RSS', text: 'Energy grid resilience under sustained pressure', pub: '2026-05-27 21:44' },
  ],

  intel: [
    { id: 'rec_8f2a', source: 'War on the Rocks', conf: 0.88, cls: 'CORROBORATED', headline: 'Disclosure-timing compression, dual-jurisdiction committees' },
    { id: 'rec_9b40', source: 'Capitol Trades', conf: 0.81, cls: 'ESCALATE', headline: 'Defense-equity disclosure 6 days post-markup' },
    { id: 'rec_4a17', source: 'Just Security', conf: 0.62, cls: 'INVESTIGATE', headline: 'Unattributed infrastructure intrusion' },
    { id: 'rec_1e93', source: 'Narrative Monitor', conf: 0.58, cls: 'MONITOR', headline: 'Narrative cluster, sim 0.79 — seeding threshold' },
    { id: 'rec_2c1d', source: 'DOJ FARA', conf: 0.44, cls: 'INVESTIGATE', headline: 'Amended registrant–principal relationship' },
    { id: 'rec_7d50', source: 'Atlantic Council', conf: 0.31, cls: 'ARCHIVE', headline: 'Energy grid resilience commentary' },
  ],

  leads: [
    { title: 'Monitor sub-7-day disclosure deltas for finance-tech dual-jurisdiction members', pri: 'CRITICAL', cat: 'GEOPOLITICAL', conf: 0.88,
      summary: 'Two outliers this cycle disclosed defense-sector positions under 7 days after closed markup. Pattern is consistent with pre-public information asymmetry.',
      actions: ['Pull markup calendar for the relevant subcommittee', 'Cross-reference QuiverQuant + Capitol Trades for the members', 'Flag any future delta < 7 days for escalation'] },
    { title: 'Corroborate narrative cluster with second independent source', pri: 'HIGH', cat: 'PSYOP', conf: 0.58,
      summary: 'Four tracked outlets converged on near-identical framing of an infrastructure intrusion. Similarity 0.79 clears the seeding threshold but not corroboration.',
      actions: ['Run campaign-level aggregation over 14-day window', 'Check for publication-silence pattern among non-participating outlets'] },
    { title: 'Re-verify amended FARA registrant–principal relationship', pri: 'MEDIUM', cat: 'FARA', conf: 0.44,
      summary: 'Filing amended 2026-05-26 introduced a previously undisclosed principal in a defense-adjacent network.',
      actions: ['Diff the amended filing against prior version', 'Map principal against congressional activity registry'] },
  ],

  psyop: [
    { score: 0.81, cls: 'HIGH_RISK', excerpt: '"Everyone already knows the real story — the so-called experts are just covering for…"', patterns: ['FALSE_CONSENSUS', 'SOURCE_DISCREDITING', 'URGENCY'] },
    { score: 0.54, cls: 'MEDIUM_RISK', excerpt: '"Sources confirm what we\'ve been saying all along about the situation developing…"', patterns: ['VAGUE_ATTRIBUTION', 'NARRATIVE_SEEDING'] },
    { score: 0.18, cls: 'CLEAN', excerpt: '"The committee released its markup schedule for the upcoming session on Tuesday."', patterns: [] },
  ],

  fara: [
    { id: 'fara_0091', registrant: 'Northbridge Strategies LLC', country: 'Cyprus', principal: 'Helios Maritime Group', date: '2026-05-26' },
    { id: 'fara_0088', registrant: 'Cassidy & Vale Public Affairs', country: 'UAE', principal: 'Gulf Infrastructure Authority', date: '2026-05-24' },
    { id: 'fara_0085', registrant: 'Meridian Advisory Partners', country: 'Kazakhstan', principal: 'Steppe Energy Holdings', date: '2026-05-21' },
  ],
};
