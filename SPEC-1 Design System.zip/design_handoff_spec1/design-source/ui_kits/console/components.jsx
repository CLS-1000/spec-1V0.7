/* SPEC-1 Console — components (exported to window for cross-file use) */
const { useState } = React;

// ── Primitives ──────────────────────────────────────────────────────────────
function Badge({ text }) {
  if (!text) return null;
  const cls = 'badge-' + String(text).toLowerCase().replace(/[^a-z0-9]/g, '-');
  return <span className={'badge ' + cls}>{text}</span>;
}

function ConfBar({ v }) {
  const pv = Math.min(1, Math.max(0, v || 0));
  return (
    <div className="conf-wrap">
      <div className="conf-track"><div className="conf-fill" style={{ width: (pv * 100) + '%' }} /></div>
      <span className="conf-val">{pv.toFixed(2)}</span>
    </div>
  );
}

// minimal markdown: **bold**, `code`, - lists, paragraphs
function MD({ text }) {
  if (!text) return null;
  const inline = (s) => {
    const parts = [];
    let rest = s, key = 0;
    const re = /(\*\*([^*]+)\*\*|`([^`]+)`)/;
    let m;
    while ((m = rest.match(re))) {
      if (m.index > 0) parts.push(rest.slice(0, m.index));
      if (m[2]) parts.push(<strong key={key++}>{m[2]}</strong>);
      else if (m[3]) parts.push(<code key={key++}>{m[3]}</code>);
      rest = rest.slice(m.index + m[0].length);
    }
    parts.push(rest);
    return parts;
  };
  const blocks = [];
  let list = null;
  text.split('\n').forEach((line, i) => {
    if (/^- /.test(line)) { (list = list || []).push(line.slice(2)); return; }
    if (list) { blocks.push(<ul key={'u' + i}>{list.map((li, j) => <li key={j}>{inline(li)}</li>)}</ul>); list = null; }
    if (line.trim()) blocks.push(<p key={i}>{inline(line)}</p>);
  });
  if (list) blocks.push(<ul key="u-last">{list.map((li, j) => <li key={j}>{inline(li)}</li>)}</ul>);
  return <div className="md">{blocks}</div>;
}

function PanelHead({ glyph, title, sub }) {
  return (
    <React.Fragment>
      <div className="panel-title">{glyph} {title}</div>
      <div className="panel-sub">{sub}</div>
    </React.Fragment>
  );
}

// ── Header ──────────────────────────────────────────────────────────────────
function Header({ online, version }) {
  return (
    <header>
      <div className="logo"><span className="logo-badge">S1</span>SPEC-1 Intelligence Engine</div>
      <div id="api-status">
        <span className={'status-geo ' + (online ? 'online' : 'offline')} />
        <span>{online ? 'API Live · v' + version : 'API Offline'}</span>
      </div>
    </header>
  );
}

// ── Sidebar ─────────────────────────────────────────────────────────────────
const NAV = [
  { sec: 'Intelligence' },
  { id: 'brief', glyph: '◈', label: 'Daily Brief' },
  { id: 'archive', glyph: '◻', label: 'Archive' },
  { sec: 'Signals' },
  { id: 'signals', glyph: '⊹', label: 'Raw Signals' },
  { id: 'intel', glyph: '▣', label: 'Intel Records' },
  { id: 'leads', glyph: '◈', label: 'Leads' },
  { sec: 'Analysis' },
  { id: 'psyop', glyph: '⊗', label: 'Psyop' },
  { id: 'fara', glyph: '⊡', label: 'FARA' },
  { sec: 'Operations' },
  { id: 'cycle', glyph: '▷', label: 'Cycle' },
];

function Sidebar({ active, onNav }) {
  return (
    <nav>
      {NAV.map((n, i) => n.sec
        ? <React.Fragment key={i}>{i > 0 && <div className="nav-divider" />}<div className="nav-section">{n.sec}</div></React.Fragment>
        : <div key={n.id} className={'nav-item' + (active === n.id ? ' active' : '')} onClick={() => onNav(n.id)}>
            <span className="nav-glyph">{n.glyph}</span> {n.label}
          </div>
      )}
    </nav>
  );
}

// ── Panels ──────────────────────────────────────────────────────────────────
function BriefPanel({ data }) {
  const b = data.brief;
  return (
    <div className="panel">
      <PanelHead glyph="◈" title="Daily Brief" sub="Latest world intelligence brief" />
      <div className="brief-wrap">
        <div className="brief-id-row">
          <span className="tag">{b.date}</span>
          <span className="tag">CONF {Math.round(b.confidence * 100)}%</span>
          <span className="tag">{b.produced}</span>
          <span className="tag" style={{ opacity: .5 }}>{b.brief_id}</span>
        </div>
        <div className="md">
          <h1>{b.headline}</h1>
          <MD text={b.summary} />
          {b.sections.map((s, i) => <React.Fragment key={i}><h2>{s.title}</h2><MD text={s.body} /></React.Fragment>)}
          <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 18 }}>Sources: {b.sources.join(', ')}</p>
        </div>
      </div>
    </div>
  );
}

function ArchivePanel({ data, onOpen }) {
  const [open, setOpen] = useState(null);
  if (open) {
    const a = open;
    return (
      <div className="panel">
        <PanelHead glyph="◻" title="Brief Archive" sub="All generated briefs, newest first" />
        <button className="back-btn" onClick={() => setOpen(null)}>← Back to Archive</button>
        <div className="brief-wrap">
          <div className="brief-id-row"><span className="tag">{a.date}</span><span className="tag">CONF {Math.round(a.conf * 100)}%</span><span className="tag" style={{ opacity: .5 }}>{a.id}</span></div>
          <div className="md"><h1>{a.headline}</h1><MD text={`This is the archived brief for ${a.date}. ${a.words} words. Every claim traces back to a scored \`IntelligenceRecord\`. Select **Daily Brief** for the full latest edition.`} /></div>
        </div>
      </div>
    );
  }
  return (
    <div className="panel">
      <PanelHead glyph="◻" title="Brief Archive" sub="All generated briefs, newest first — click a card to read" />
      <div className="archive-bar"><span /><span className="archive-count">{data.archive.length} briefs</span></div>
      <div className="brief-cards">
        {data.archive.map(a => (
          <div className="brief-card" key={a.id} onClick={() => setOpen(a)}>
            <div className="card-date">{a.date}</div>
            <div className="card-headline">{a.headline}</div>
            <div className="card-meta"><span>{a.words} words</span><span>CONF {Math.round(a.conf * 100)}%</span><span style={{ opacity: .5 }}>{a.id}</span></div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SignalsPanel({ data }) {
  const [q, setQ] = useState('');
  const rows = data.signals.filter(s => !q || s.type.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="panel">
      <PanelHead glyph="⊹" title="Raw Signals" sub="OSINT signals from all adapters (RSS, FARA, Congressional, Narrative)" />
      <div className="filter-bar">
        <label>Source type</label>
        <input className="filter-input" placeholder="e.g. RSS" style={{ width: 130 }} value={q} onChange={e => setQ(e.target.value)} />
        <button className="filter-btn" onClick={() => setQ('')}>Clear</button>
        <span className="count-chip">{rows.length} of {data.signals.length} signals</span>
      </div>
      <div className="table-wrap">
        <table className="data-table">
          <thead><tr><th>ID</th><th>Source</th><th>Type</th><th>Text</th><th>Published</th></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td className="table-empty" colSpan="5">No signals match “{q}”</td></tr>}
            {rows.map(r => (
              <tr key={r.id}>
                <td><span className="mono-id">{r.id}</span></td>
                <td>{r.source}</td>
                <td><Badge text={r.type} /></td>
                <td><span className="cell-trunc" title={r.text}>{r.text}</span></td>
                <td>{r.pub}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function IntelPanel({ data }) {
  const [cls, setCls] = useState('');
  const rows = data.intel.filter(r => !cls || r.cls === cls);
  return (
    <div className="panel">
      <PanelHead glyph="▣" title="Intel Records" sub="Analyzed intelligence records scored through the 4-gate pipeline" />
      <div className="filter-bar">
        <label>Classification</label>
        <select className="filter-select" style={{ width: 160 }} value={cls} onChange={e => setCls(e.target.value)}>
          <option value="">All</option><option>CORROBORATED</option><option>ESCALATE</option><option>INVESTIGATE</option><option>MONITOR</option><option>ARCHIVE</option>
        </select>
        <button className="filter-btn" onClick={() => setCls('')}>Clear</button>
        <span className="count-chip">{rows.length} of {data.intel.length} records</span>
      </div>
      <div className="table-wrap">
        <table className="data-table">
          <thead><tr><th>ID</th><th>Headline</th><th>Source</th><th>Confidence</th><th>Class</th></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td className="table-empty" colSpan="5">No records classified {cls}</td></tr>}
            {rows.map(r => (
              <tr key={r.id}>
                <td><span className="mono-id">{r.id}</span></td>
                <td><span className="cell-trunc" title={r.headline}>{r.headline}</span></td>
                <td>{r.source}</td>
                <td><ConfBar v={r.conf} /></td>
                <td><Badge text={r.cls} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function LeadsPanel({ data }) {
  return (
    <div className="panel">
      <PanelHead glyph="◈" title="Leads" sub="Actionable intelligence leads generated from verified records" />
      {data.leads.map((l, i) => (
        <div className="lead-card" key={i}>
          <div className="lead-header"><div className="lead-title">{l.title}</div><Badge text={l.pri} /></div>
          <div className="lead-summary">{l.summary}</div>
          <div className="lead-actions">{l.actions.map((a, j) => <div className="lead-action-item" key={j}>{a}</div>)}</div>
          <div className="lead-meta"><Badge text={l.cat} /><span>CONF {Math.round(l.conf * 100)}%</span></div>
        </div>
      ))}
    </div>
  );
}

function PsyopPanel({ data }) {
  const [text, setText] = useState('');
  const [result, setResult] = useState(null);
  const analyse = () => {
    const t = text.toLowerCase();
    let score = 0; const pats = [];
    if (/everyone|already knows|so-called/.test(t)) { score += .4; pats.push('FALSE_CONSENSUS'); }
    if (/sources confirm|sources say|experts/.test(t)) { score += .25; pats.push('VAGUE_ATTRIBUTION'); }
    if (/now|urgent|before it/.test(t)) { score += .2; pats.push('URGENCY'); }
    if (!pats.length) score = .12;
    const cls = score >= .7 ? 'HIGH_RISK' : score >= .4 ? 'MEDIUM_RISK' : score >= .2 ? 'LOW_RISK' : 'CLEAN';
    setResult({ score: Math.min(score, .95), cls, patterns: pats });
  };
  return (
    <div className="panel">
      <PanelHead glyph="⊗" title="Psyop Detection" sub="Psychological-operation pattern scoring and evidence chains" />
      <div className="section-heading">Analyse Text</div>
      <div className="state-box" style={{ marginBottom: 22 }}>
        <div className="form-grid">
          <div>
            <label className="form-label">Text to analyse</label>
            <textarea className="form-textarea" rows="3" placeholder="Paste a headline, post, or narrative text…" value={text} onChange={e => setText(e.target.value)} />
          </div>
          <div>
            <button className="form-submit" onClick={analyse}>Analyse for Psyop Patterns</button>
            {result && <div className="form-msg ok">Score {result.score.toFixed(2)} · <Badge text={result.cls.replace('_', '-')} /> {result.patterns.join(' · ') || 'no patterns detected'}</div>}
          </div>
        </div>
      </div>
      <div className="section-sep" />
      <div className="section-heading">Stored Scores</div>
      {data.psyop.map((p, i) => (
        <div className="psyop-card" key={i}>
          <div className="psyop-header"><Badge text={p.cls.replace('_', '-')} /><div className="psyop-score-val">{p.score.toFixed(2)}</div></div>
          <div className="psyop-excerpt">{p.excerpt}</div>
          {p.patterns.length > 0 && <div className="psyop-patterns">{p.patterns.map(pt => <span className="psyop-pattern" key={pt}>{pt}</span>)}</div>}
        </div>
      ))}
    </div>
  );
}

function FaraPanel({ data }) {
  return (
    <div className="panel">
      <PanelHead glyph="⊡" title="FARA Records" sub="Foreign Agents Registration Act filings from the OSINT store" />
      <div className="filter-bar"><span className="count-chip">{data.fara.length} filings</span></div>
      <div className="table-wrap">
        <table className="data-table">
          <thead><tr><th>ID</th><th>Registrant</th><th>Country</th><th>Principal</th><th>Filed</th></tr></thead>
          <tbody>
            {data.fara.map(f => (
              <tr key={f.id}><td><span className="mono-id">{f.id}</span></td><td>{f.registrant}</td><td><Badge text={f.country} /></td><td>{f.principal}</td><td>{f.date}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CyclePanel({ data }) {
  const [state, setState] = useState('idle'); // idle | running | done
  const run = () => {
    if (state === 'running') return;
    setState('running');
    setTimeout(() => setState('done'), 2600);
  };
  return (
    <div className="panel">
      <PanelHead glyph="▷" title="Cycle" sub="Trigger and monitor the full SPEC-1 intelligence pipeline" />
      <div className="stats-grid">
        <div className="stat-box"><div className="stat-label">Signals</div><div className="stat-value">{data.stats.signals.toLocaleString()}</div><div className="stat-sub">harvested</div></div>
        <div className="stat-box"><div className="stat-label">Intel</div><div className="stat-value">{data.stats.intel}</div><div className="stat-sub">records</div></div>
        <div className="stat-box"><div className="stat-label">Leads</div><div className="stat-value">{data.stats.leads}</div><div className="stat-sub">actionable</div></div>
        <div className="stat-box"><div className="stat-label">Briefs</div><div className="stat-value">{data.stats.briefs}</div><div className="stat-sub">archived</div></div>
      </div>
      <div className="cycle-run-box">
        <div className="section-heading">Run Cycle</div>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 14, lineHeight: 1.6 }}>
          Harvest signals → parse → 4-gate score → investigate → verify → store. Runs synchronously; may take 30–90 seconds depending on feed volume.
        </p>
        <button className="run-btn" onClick={run} disabled={state === 'running'}>▷ Run Intelligence Cycle</button>
        <div className={'run-msg ' + state}>
          {state === 'running' && <React.Fragment><span className="spinner" /> &nbsp;HARVEST → PARSE → SCORE → INVESTIGATE<span className="cursor" /></React.Fragment>}
          {state === 'done' && '[OK] Cycle complete · 1,284 harvested → 47 records → 12 leads · brief generated'}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  S1: { Header, Sidebar, BriefPanel, ArchivePanel, SignalsPanel, IntelPanel, LeadsPanel, PsyopPanel, FaraPanel, CyclePanel },
});
