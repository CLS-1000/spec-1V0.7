# SPEC-1 Console — UI Kit

A pixel-accurate, interactive recreation of the **SPEC-1 analyst dashboard**
(`spec1_ui.html` in the source repo). The console is the operator-facing app:
sidebar navigation across intelligence products, dense data tables, the daily
brief, scored leads, and the pipeline cycle runner.

## Run
Open `index.html`. Everything is client-side React (via Babel) with fake demo
data — no API required.

## What's interactive
- **Sidebar nav** switches panels (active state = left rule + white text).
- **Daily Brief** renders a structured, markdown-formatted intelligence brief.
- **Archive** → click any brief card to open its detail; **← Back** to return.
- **Raw Signals** — filter by source type.
- **Intel Records** — filter by classification; confidence bars + class badges.
- **Leads** — actionable leads with `▸` action lists and priority badges.
- **Psyop** — paste text and **Analyse** it; a rule-based scorer returns a live
  score, classification, and detected patterns. Stored scores listed below.
- **FARA** — registrant / principal filings table.
- **Cycle** — **▷ Run Intelligence Cycle** plays a fake harvest→store run with a
  spinner + blinking cursor, then an `[OK]` completion line.

## Files
| File | Role |
|---|---|
| `index.html` | Mounts React, loads the Flower-of-Life background, renders `App` |
| `styles.css` | Console stylesheet, lifted from `spec1_ui.html` for fidelity |
| `data.js` | `window.S1_DATA` — demo signals, intel, leads, psyop, FARA, briefs |
| `components.jsx` | All panels + primitives (`Badge`, `ConfBar`, `MD`), exported on `window.S1` |

## Notes
- Glyph icons are Unicode (`◈ ◻ ⊹ ▣ ⊗ ⊡ ▷`), matching the product. No icon font.
- Badge severity is encoded by border/text opacity, not hue.
- Pure monochrome + the two signal accents only. No shadows, no radius.
