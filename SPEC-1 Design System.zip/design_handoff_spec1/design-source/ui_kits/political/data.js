/* ============================================================================
   SPEC-1 Political Intelligence — PDX-1i Portland metro political web
   Demo graph for the force-directed "web map" + signal feed.
   Officials are role-based placeholders (not real individuals) except the one
   documented public fact: the Metro Council President vacancy (appt 2026-06-11).
   ========================================================================== */
window.PDX = (function () {

  // ── Node types: jurisdiction · official · entity ──────────────────────────
  // group: J = jurisdiction, O = official, E = entity
  const nodes = [
    // ── Jurisdictions (8) ──
    { id: 'metro',     label: 'Metro Council',          group: 'J', weight: 1.0 },
    { id: 'multco',    label: 'Multnomah County',       group: 'J', weight: 0.9 },
    { id: 'washco',    label: 'Washington County',      group: 'J', weight: 0.8 },
    { id: 'clackco',   label: 'Clackamas County',       group: 'J', weight: 0.7 },
    { id: 'portland',  label: 'City of Portland',       group: 'J', weight: 1.0 },
    { id: 'clarkwa',   label: 'Clark County · WA',      group: 'J', weight: 0.6 },
    { id: 'trimet_b',  label: 'TriMet Board',           group: 'J', weight: 0.7 },
    { id: 'port',      label: 'Port of Portland',       group: 'J', weight: 0.7 },

    // ── Officials (role-based placeholders) ──
    { id: 'mcp',       label: 'Metro Council Pres. [VACANT]', group: 'O', weight: 1.0, flag: 'VACANT' },
    { id: 'mc_d2',     label: 'Metro Councilor · D2',   group: 'O', weight: 0.6 },
    { id: 'mc_d4',     label: 'Metro Councilor · D4',   group: 'O', weight: 0.6 },
    { id: 'pdx_mayor', label: 'Portland Mayor',         group: 'O', weight: 0.9 },
    { id: 'pdx_c1',    label: 'City Councilor · Dist 1',group: 'O', weight: 0.6 },
    { id: 'pdx_c3',    label: 'City Councilor · Dist 3',group: 'O', weight: 0.6 },
    { id: 'mult_ch',   label: 'Multnomah Chair',        group: 'O', weight: 0.7 },
    { id: 'wash_c2',   label: 'Washington Comm. · P2',  group: 'O', weight: 0.5 },
    { id: 'clack_c',   label: 'Clackamas Chair',        group: 'O', weight: 0.5 },
    { id: 'clark_c',   label: 'Clark Councilor · WA',   group: 'O', weight: 0.4 },

    // ── Monitored entities (17) ──
    { id: 'pge',       label: 'Portland General Electric', group: 'E', weight: 0.9 },
    { id: 'nwn',       label: 'NW Natural',             group: 'E', weight: 0.8 },
    { id: 'pwb',       label: 'Portland Water Bureau',  group: 'E', weight: 0.7 },
    { id: 'trimet',    label: 'TriMet',                 group: 'E', weight: 0.9 },
    { id: 'ppb',       label: 'Portland Police Bureau', group: 'E', weight: 0.8 },
    { id: 'ohsu',      label: 'OHSU',                   group: 'E', weight: 0.8 },
    { id: 'schn',      label: 'Schnitzer / Radius',     group: 'E', weight: 0.7 },
    { id: 'pcef',      label: 'Clean Energy Fund',      group: 'E', weight: 0.6 },
    { id: 'home_fwd',  label: 'Home Forward',           group: 'E', weight: 0.5 },
    { id: 'prosper',   label: 'Prosper Portland',       group: 'E', weight: 0.6 },
    { id: 'zenith',    label: 'Zenith Energy',          group: 'E', weight: 0.6 },
    { id: 'nike',      label: 'Nike (Washington Co.)',  group: 'E', weight: 0.5 },
    { id: 'intel',     label: 'Intel (Hillsboro)',      group: 'E', weight: 0.6 },
  ];

  // ── Edges: kind = seat | tie | regulates | operates | disclosure ──
  const links = [
    // Metro
    { s: 'mcp', t: 'metro', kind: 'seat' },
    { s: 'mc_d2', t: 'metro', kind: 'seat' },
    { s: 'mc_d4', t: 'metro', kind: 'seat' },
    { s: 'metro', t: 'trimet', kind: 'operates' },
    { s: 'metro', t: 'pcef', kind: 'operates' },
    // Portland
    { s: 'pdx_mayor', t: 'portland', kind: 'seat' },
    { s: 'pdx_c1', t: 'portland', kind: 'seat' },
    { s: 'pdx_c3', t: 'portland', kind: 'seat' },
    { s: 'portland', t: 'pwb', kind: 'operates' },
    { s: 'portland', t: 'ppb', kind: 'operates' },
    { s: 'portland', t: 'pcef', kind: 'operates' },
    { s: 'portland', t: 'prosper', kind: 'operates' },
    { s: 'portland', t: 'pge', kind: 'regulates' },
    { s: 'portland', t: 'nwn', kind: 'regulates' },
    { s: 'portland', t: 'zenith', kind: 'regulates' },
    // Multnomah
    { s: 'mult_ch', t: 'multco', kind: 'seat' },
    { s: 'multco', t: 'home_fwd', kind: 'operates' },
    { s: 'multco', t: 'ohsu', kind: 'tie' },
    { s: 'multco', t: 'ppb', kind: 'tie' },
    // Washington
    { s: 'wash_c2', t: 'washco', kind: 'seat' },
    { s: 'washco', t: 'nike', kind: 'tie' },
    { s: 'washco', t: 'intel', kind: 'tie' },
    { s: 'washco', t: 'nwn', kind: 'regulates' },
    // Clackamas
    { s: 'clack_c', t: 'clackco', kind: 'seat' },
    { s: 'clackco', t: 'pge', kind: 'regulates' },
    // Clark WA
    { s: 'clark_c', t: 'clarkwa', kind: 'seat' },
    { s: 'clarkwa', t: 'nwn', kind: 'tie' },
    // TriMet / Port
    { s: 'trimet_b', t: 'trimet', kind: 'seat' },
    { s: 'metro', t: 'trimet_b', kind: 'tie' },
    { s: 'port', t: 'schn', kind: 'operates' },
    { s: 'port', t: 'zenith', kind: 'operates' },
    { s: 'port', t: 'intel', kind: 'tie' },
    // Cross / disclosure ties (the "web")
    { s: 'mcp', t: 'pge', kind: 'disclosure', flag: 1 },
    { s: 'pdx_mayor', t: 'ohsu', kind: 'disclosure' },
    { s: 'pdx_c3', t: 'zenith', kind: 'disclosure', flag: 1 },
    { s: 'mult_ch', t: 'schn', kind: 'tie' },
    { s: 'wash_c2', t: 'intel', kind: 'disclosure' },
    { s: 'mc_d4', t: 'trimet', kind: 'tie' },
    { s: 'ohsu', t: 'pcef', kind: 'tie' },
    { s: 'pge', t: 'pcef', kind: 'regulates' },
  ];

  // ── Signal feed (demo records) for the PDX-1i feed panel ──
  const records = [
    { src: 'ORESTAR', date: '2026-05-28', cls: 'ESCALATE', pri: 'ELEVATED', conf: 0.84,
      pattern: 'Contribution cluster to Metro Council seats from a regulated-utility-affiliated PAC inside the 90-day window.',
      gates: { credibility: 1, volume: 1, velocity: 1, novelty: 1 } },
    { src: 'OLIS', date: '2026-05-27', cls: 'INVESTIGATE', pri: 'ELEVATED', conf: 0.71,
      pattern: 'Committee markup on energy-siting rule precedes a public Zenith terminal announcement by 6 days.',
      gates: { credibility: 1, volume: 1, velocity: 1, novelty: 0 } },
    { src: 'SEI', date: '2026-05-26', cls: 'MONITOR', pri: 'STANDARD', conf: 0.55,
      pattern: 'Statement-of-economic-interest amendment adds a previously undisclosed OHSU advisory position.',
      gates: { credibility: 1, volume: 0, velocity: 1, novelty: 1 } },
    { src: 'WA PDC', date: '2026-05-25', cls: 'INVESTIGATE', pri: 'STANDARD', conf: 0.62,
      pattern: 'Clark County cross-border contribution flagged against NW Natural rate-case timeline.',
      gates: { credibility: 1, volume: 1, velocity: 0, novelty: 1 } },
    { src: 'ORESTAR', date: '2026-05-24', cls: 'ARCHIVE', pri: 'MONITOR', conf: 0.29,
      pattern: 'Routine in-district small-dollar contributions; no entity overlap detected.',
      gates: { credibility: 1, volume: 1, velocity: 1, novelty: 0 } },
    { src: 'OLIS', date: '2026-05-23', cls: 'MONITOR', pri: 'STANDARD', conf: 0.48,
      pattern: 'TriMet board appointment correlates with transit-adjacent property disclosure.',
      gates: { credibility: 1, volume: 1, velocity: 1, novelty: 1 } },
  ];

  // ── District map: bi-state metro jurisdictions → districts → elected seats ──
  // NEUTRAL ROSTER of who holds which public seat (public record, as of May 2026).
  // Sources: oregonmetro.gov, portland.gov, county boards. Seats without a verified
  // named holder are shown by role. No conflict/"signal" framing is attached to any
  // named individual — that illustrative layer lives only in the demo Web Map.
  const districts = [
    { jur: 'Clark County', state: 'WA', zone: 'north', seats: [
      { d: 'Chair', role: 'Council Chair · at-large', status: 'seated' },
      { d: 'D1', role: 'Councilor', status: 'seated' },
      { d: 'D2', role: 'Councilor', status: 'seated' },
      { d: 'D3', role: 'Councilor', status: 'seated' },
      { d: 'D4', role: 'Councilor', status: 'seated' },
    ] },
    { jur: 'Washington County', state: 'OR', zone: 'west', seats: [
      { d: 'Chair', role: 'Kathryn Harrington · at-large', status: 'seated' },
      { d: 'D1', role: 'Nafisa Fai', status: 'seated' },
      { d: 'D2', role: 'Pam Treece', status: 'seated' },
      { d: 'D3', role: 'Jason Snider', status: 'seated' },
      { d: 'D4', role: 'Jerry Willey', status: 'seated' },
    ] },
    { jur: 'City of Portland', state: 'OR', zone: 'center', seats: [
      { d: 'Mayor', role: 'Keith Wilson · citywide', status: 'seated' },
      { d: 'D1', role: 'Councilors ×3 · East', status: 'seated' },
      { d: 'D2', role: 'Councilors ×3 · N/NE', status: 'seated' },
      { d: 'D3', role: 'Councilors ×3 · SE', status: 'seated' },
      { d: 'D4', role: 'Councilors ×3 · W/SW', status: 'seated' },
    ] },
    { jur: 'Multnomah County', state: 'OR', zone: 'east', seats: [
      { d: 'Chair', role: 'Jessica Vega Pederson', status: 'seated' },
      { d: 'D1', role: 'Commissioner', status: 'seated' },
      { d: 'D2', role: 'Commissioner', status: 'seated' },
      { d: 'D3', role: 'Commissioner', status: 'seated' },
      { d: 'D4', role: 'Commissioner', status: 'seated' },
    ] },
    { jur: 'Clackamas County', state: 'OR', zone: 'south', seats: [
      { d: 'Chair', role: 'Board Chair · at-large', status: 'seated' },
      { d: 'D1', role: 'Commissioner', status: 'seated' },
      { d: 'D2', role: 'Commissioner', status: 'seated' },
      { d: 'D3', role: 'Commissioner', status: 'seated' },
      { d: 'D4', role: 'Commissioner', status: 'seated' },
    ] },
    { jur: 'Metro Council', state: 'REGIONAL', zone: 'band', seats: [
      { d: 'Pres', role: 'President · Peterson resigned', status: 'vacant' },
      { d: 'D1', role: 'Ashton Simpson', status: 'seated' },
      { d: 'D2', role: 'Christine Lewis', status: 'seated' },
      { d: 'D3', role: 'Gerritt Rosenthal', status: 'seated' },
      { d: 'D4', role: 'Juan Carlos González', status: 'seated' },
      { d: 'D5', role: 'Mary Nolan', status: 'seated' },
      { d: 'D6', role: 'Duncan Hwang · Acting Pres', status: 'flagged' },
    ] },
  ];

  const legend = {
    J: 'Jurisdiction', O: 'Official', E: 'Monitored entity',
  };
  const kindLabel = {
    seat: 'holds seat', tie: 'affiliation', regulates: 'regulates',
    operates: 'operates', disclosure: 'disclosure tie',
  };

  return { nodes, links, records, districts, legend, kindLabel };
})();
