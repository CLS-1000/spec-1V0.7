/* ============================================================================
   SPEC-1 — Political Web Map
   A dimensional (3D-rotating) force-directed network of the PDX-1i Portland
   metro political web. Vanilla canvas. Monochrome terminal aesthetic.
   Auto-orbits; drag to rotate; hover to trace ties; click to pin a node.
   ============================================================================ */
(function () {
  'use strict';

  const GROUP = {
    J: { shape: 'diamond', label: 'Jurisdiction' },
    O: { shape: 'square',  label: 'Official' },
    E: { shape: 'circle',  label: 'Entity' },
  };

  function WebMap(canvas, data, opts) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.opts = opts || {};
    this.onSelect = this.opts.onSelect || function () {};

    // Build node objects with adjacency
    this.nodes = data.nodes.map(n => Object.assign({}, n, {
      x: (Math.random() - 0.5) * 300,
      y: (Math.random() - 0.5) * 300,
      z: (Math.random() - 0.5) * 300,
      vx: 0, vy: 0, vz: 0, deg: 0,
    }));
    this.index = {};
    this.nodes.forEach(n => { this.index[n.id] = n; });
    this.links = data.links.map(l => ({ s: this.index[l.s], t: this.index[l.t], kind: l.kind, flag: l.flag }));
    this.links.forEach(l => { if (l.s && l.t) { l.s.deg++; l.t.deg++; } });
    this.kindLabel = data.kindLabel || {};

    // neighbor sets
    this.neighbors = {};
    this.nodes.forEach(n => { this.neighbors[n.id] = new Set(); });
    this.links.forEach(l => { if (l.s && l.t) { this.neighbors[l.s.id].add(l.t.id); this.neighbors[l.t.id].add(l.s.id); } });

    // view state
    this.rotY = 0.4; this.rotX = -0.15;
    this.auto = true;
    this.hover = null;
    this.selected = null;
    this.dragging = false;
    this.lastX = 0; this.lastY = 0;
    this.focal = 560;
    this.proj = []; // projected screen positions

    this._resize();
    this._bind();
    this._loop = this._loop.bind(this);
    // warm up the simulation so the first painted frame is already settled
    for (let i = 0; i < 80; i++) this._physics();
    this._loop(); // paint immediately; _loop re-requests itself via rAF
  }

  WebMap.prototype._resize = function () {
    const r = this.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = r.width * dpr;
    this.canvas.height = r.height * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.W = r.width; this.H = r.height;
  };

  WebMap.prototype._bind = function () {
    const c = this.canvas;
    window.addEventListener('resize', () => this._resize());

    c.addEventListener('mousedown', e => {
      this.dragging = true; this.auto = false;
      this.lastX = e.clientX; this.lastY = e.clientY;
    });
    window.addEventListener('mouseup', () => { this.dragging = false; });
    window.addEventListener('mousemove', e => {
      if (this.dragging) {
        this.rotY += (e.clientX - this.lastX) * 0.006;
        this.rotX += (e.clientY - this.lastY) * 0.006;
        this.rotX = Math.max(-1.2, Math.min(1.2, this.rotX));
        this.lastX = e.clientX; this.lastY = e.clientY;
      }
    });

    c.addEventListener('mousemove', e => {
      const r = c.getBoundingClientRect();
      const mx = e.clientX - r.left, my = e.clientY - r.top;
      let best = null, bd = 18 * 18;
      for (const p of this.proj) {
        const dx = p.sx - mx, dy = p.sy - my;
        const d = dx * dx + dy * dy;
        if (d < bd) { bd = d; best = p.node; }
      }
      this.hover = best;
      c.style.cursor = best ? 'pointer' : (this.dragging ? 'grabbing' : 'grab');
    });
    c.addEventListener('mouseleave', () => { this.hover = null; });
    c.addEventListener('click', () => {
      if (this.hover) {
        this.selected = (this.selected === this.hover) ? null : this.hover;
        this.onSelect(this.selected ? this._detail(this.selected) : null);
      } else {
        this.selected = null; this.onSelect(null);
      }
    });
  };

  WebMap.prototype._detail = function (n) {
    const ties = this.links.filter(l => l.s === n || l.t === n).map(l => {
      const other = l.s === n ? l.t : l.s;
      return { label: other.label, kind: this.kindLabel[l.kind] || l.kind, flag: l.flag };
    });
    return { id: n.id, label: n.label, group: GROUP[n.group].label, flag: n.flag, deg: n.deg, ties };
  };

  // ── Force simulation step (3D) ──
  WebMap.prototype._physics = function () {
    const N = this.nodes;
    for (let i = 0; i < N.length; i++) {
      const a = N[i];
      for (let j = i + 1; j < N.length; j++) {
        const b = N[j];
        let dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
        let d2 = dx * dx + dy * dy + dz * dz + 0.01;
        let d = Math.sqrt(d2);
        const rep = 2600 / d2;
        const ux = dx / d, uy = dy / d, uz = dz / d;
        a.vx += ux * rep; a.vy += uy * rep; a.vz += uz * rep;
        b.vx -= ux * rep; b.vy -= uy * rep; b.vz -= uz * rep;
      }
    }
    for (const l of this.links) {
      if (!l.s || !l.t) continue;
      let dx = l.t.x - l.s.x, dy = l.t.y - l.s.y, dz = l.t.z - l.s.z;
      let d = Math.sqrt(dx * dx + dy * dy + dz * dz) + 0.01;
      const target = 150;
      const f = (d - target) * 0.012;
      const ux = dx / d, uy = dy / d, uz = dz / d;
      l.s.vx += ux * f; l.s.vy += uy * f; l.s.vz += uz * f;
      l.t.vx -= ux * f; l.t.vy -= uy * f; l.t.vz -= uz * f;
    }
    for (const n of N) {
      // centering
      n.vx -= n.x * 0.0016; n.vy -= n.y * 0.0016; n.vz -= n.z * 0.0016;
      n.vx *= 0.86; n.vy *= 0.86; n.vz *= 0.86;
      n.x += n.vx; n.y += n.vy; n.z += n.vz;
    }
  };

  WebMap.prototype._project = function (n) {
    const cosY = Math.cos(this.rotY), sinY = Math.sin(this.rotY);
    const cosX = Math.cos(this.rotX), sinX = Math.sin(this.rotX);
    let x = n.x * cosY - n.z * sinY;
    let z = n.x * sinY + n.z * cosY;
    let y = n.y * cosX - z * sinX;
    z = n.y * sinX + z * cosX;
    const scale = this.focal / (this.focal + z);
    return { sx: this.W / 2 + x * scale, sy: this.H / 2 + y * scale, scale, z };
  };

  WebMap.prototype._loop = function () {
    this._physics();
    if (this.auto && !this.dragging) this.rotY += 0.0022;

    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.W, this.H);

    // project all
    this.proj = this.nodes.map(n => Object.assign(this._project(n), { node: n }));
    const pos = {};
    this.proj.forEach(p => { pos[p.node.id] = p; });

    const active = this.selected || this.hover;
    const lit = active ? this.neighbors[active.id] : null;

    // ── edges (back to front) ──
    const sortedLinks = this.links.slice().sort((a, b) =>
      ((pos[a.s.id].z + pos[a.t.id].z) / 2) - ((pos[b.s.id].z + pos[b.t.id].z) / 2)
    );
    for (const l of sortedLinks) {
      const ps = pos[l.s.id], pt = pos[l.t.id];
      const depth = (ps.z + pt.z) / 2;
      let alpha = 0.10 + Math.max(0, (300 - depth) / 300) * 0.16;
      const isActive = active && (l.s === active || l.t === active);
      const dim = active && !isActive;
      if (dim) alpha *= 0.18;
      if (isActive) alpha = 0.75;
      ctx.beginPath();
      ctx.moveTo(ps.sx, ps.sy); ctx.lineTo(pt.sx, pt.sy);
      ctx.strokeStyle = `rgba(255,255,255,${alpha})`;
      ctx.lineWidth = isActive ? 1.2 : 0.7;
      if (l.kind === 'disclosure') { ctx.setLineDash([3, 3]); } else { ctx.setLineDash([]); }
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // ── nodes (back to front) ──
    const order = this.proj.slice().sort((a, b) => b.z - a.z);
    for (const p of order) {
      const n = p.node;
      const r = (5 + n.weight * 7) * p.scale;
      const depthA = 0.45 + Math.max(0, (300 - p.z) / 300) * 0.55;
      const isActive = active === n;
      const isLit = lit && lit.has(n.id);
      const dim = active && !isActive && !isLit;
      let alpha = dim ? depthA * 0.22 : depthA;

      ctx.save();
      ctx.translate(p.sx, p.sy);
      ctx.globalAlpha = alpha;

      // shape by group
      const shape = GROUP[n.group].shape;
      ctx.lineWidth = isActive ? 2 : 1;
      ctx.strokeStyle = '#fff';
      ctx.fillStyle = isActive ? '#fff' : (isLit ? 'rgba(255,255,255,.14)' : '#000');

      if (shape === 'circle') {
        ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      } else if (shape === 'square') {
        ctx.beginPath(); ctx.rect(-r, -r, r * 2, r * 2); ctx.fill(); ctx.stroke();
      } else { // diamond (jurisdiction)
        ctx.beginPath();
        ctx.moveTo(0, -r * 1.25); ctx.lineTo(r * 1.25, 0); ctx.lineTo(0, r * 1.25); ctx.lineTo(-r * 1.25, 0); ctx.closePath();
        ctx.fill(); ctx.stroke();
      }

      // flag ring (e.g. VACANT)
      if (n.flag) {
        ctx.globalAlpha = alpha;
        ctx.strokeStyle = '#00FF00';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(0, 0, r + 4, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.restore();

      // labels: always for big nodes; for active/lit on interaction
      const showLabel = n.weight >= 0.8 || isActive || isLit;
      if (showLabel && !dim) {
        ctx.globalAlpha = isActive ? 1 : Math.min(1, depthA + 0.2);
        ctx.fillStyle = isActive ? '#fff' : 'rgba(255,255,255,.72)';
        ctx.font = `${isActive ? 600 : 400} ${Math.max(9, 11 * p.scale)}px 'IBM Plex Mono', monospace`;
        ctx.textAlign = 'center';
        ctx.fillText(n.label, p.sx, p.sy - r - 6 * p.scale);
        ctx.globalAlpha = 1;
      }
    }

    requestAnimationFrame(this._loop);
  };

  WebMap.prototype.setAuto = function (v) { this.auto = v; };
  WebMap.prototype.reset = function () { this.rotX = -0.15; this.rotY = 0.4; this.auto = true; this.selected = null; this.onSelect(null); };
  WebMap.prototype.focus = function (id) {
    const n = this.index[id];
    if (!n) return false;
    this.selected = n;
    this.auto = false;
    this.onSelect(this._detail(n));
    return true;
  };

  window.S1WebMap = WebMap;
})();
