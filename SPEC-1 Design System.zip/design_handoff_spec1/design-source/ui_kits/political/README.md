# SPEC-1 Political Intelligence (PDX-1i) — UI Kit

A recreation of the **SPEC-1 Political Intelligence** surface (`spec1_political_web.html`
in the source repo), extended with the **Portland metro web map** documented for the
`cls_pdx1` module (officials · entities · jurisdictions, force-directed relationship
diagram).

## Run
Open `index.html`. Vanilla JS + canvas — no build, no API, demo data only.

## Views (sidebar)
| View | What it is |
|---|---|
| **Overview** | The explainer page — *what the web map should contain*: jurisdictions, monitored entities, node/tie taxonomy, the ORESTAR/OLIS/SEI/WA-PDC feeds, and the neutrality-gated publication path. |
| **District Map** | A **schematic metro-area map** — the bi-state metro laid out geographically (Clark WA north, Washington west, Portland center, Multnomah east, Clackamas south, Metro Council as a regional band), every jurisdiction broken into its districts with the **elected seat** in each. Seats are flagged when an open signal touches them; the Metro Council President seat is ringed **vacant**. |
| **Web Map** | The **3D force-directed political web** — a rotating relationship graph. Diamonds = jurisdictions, squares = officials, circles = entities; solid edges are seats/affiliations/regulation, dashed edges are disclosure ties. Auto-orbits; **drag** to rotate, **hover** to trace a node's ties, **click** to pin its detail readout. |
| **Signal Feed** | Scored political-intelligence records — filter by classification/priority/search, expand for 4-gate results. |
| **Statistics** | Aggregate bar charts over the record set. |

## Files
| File | Role |
|---|---|
| `index.html` | Chrome, sidebar, all five panels + render logic |
| `styles.css` | Stylesheet (lifted from `spec1_political_web.html`, extended for the maps) |
| `data.js` | `window.PDX` — graph nodes/links, districts, demo records, legend |
| `webmap.js` | `window.S1WebMap` — the 3D force-directed canvas engine (physics, projection, interaction) |

## Notes & honesty
- **Officials are role-based placeholders** (e.g. "Commissioner · D2"), not named individuals.
  The only real, public fact carried is the documented Metro Council President vacancy
  (appointment deadline 2026-06-11).
- The District Map is **schematic — geographic arrangement, not to scale.** It is not GIS
  data; it's a legible tile layout in the brand aesthetic.
- The web map's physics warms up synchronously so the first painted frame is already
  settled; `requestAnimationFrame` then drives the orbit while the tab is visible.
