# Handoff: SPEC-1 Intelligence Engine — UI

> Automated OSINT signal-monitoring console. Classified-terminal aesthetic.
> `// v0.6.0 · Portland OR · EVASTARARCANA`

## Overview

This package hands off the **SPEC-1** product UI to a developer working in Claude Code.
SPEC-1 is an automated open-source-intelligence (OSINT) engine: it monitors curated
high-credibility sources, scores every incoming signal through a **four-gate deterministic
filter** (Credibility · Volume · Velocity · Novelty), and surfaces only the survivors —
classified, scored, and structured — to the analyst. The thesis: *the bottleneck is
attention, not access.*

The UI has three surfaces, all sharing one design system:

| Surface | What it is | Reference kit |
|---|---|---|
| **Console** | Analyst dashboard — sidebar nav, daily brief, signals/intel tables, leads, psyop, FARA, cycle runner | `design-source/ui_kits/console/` |
| **Web** | Marketing / portfolio site — hero, pipeline diagram, gate grid, adapters, tech | `design-source/ui_kits/web/` |
| **Political** | PDX-1i regional module — district map, 3D force-directed web map, signal feed, stats | `design-source/ui_kits/political/` |

## About the design files

The files in `design-source/` are **design references created in HTML/CSS** — prototypes
that demonstrate the intended look, layout, and behavior. **They are not production code to
copy line-for-line.** The task is to **recreate these designs inside the target codebase's
own environment** (React, Vue, Svelte, SwiftUI, native — whatever the repo uses) using its
established patterns, component primitives, and build tooling. If no app environment exists
yet, choose the most appropriate framework for the project and implement the designs there.

The HTML console kit happens to be written in React (via in-browser Babel) for prototyping
convenience; treat that as *reference structure*, not a dependency choice. Lift the **design
tokens, layout, and component anatomy** — not the `<script src="@babel/standalone">` setup.

## Fidelity

**High-fidelity (hifi).** These are pixel-level mockups with final colors, typography,
spacing, tracking, and interaction states. Recreate the UI faithfully using the codebase's
existing libraries. Exact values are in **Design Tokens** below and in
`design-source/colors_and_type.css` (the single source of truth — copy these tokens into the
target app's theme layer verbatim).

---

## Design language (read this first)

The system reads as **a CRT terminal crossed with a printed classified document.** Three
rules govern everything:

1. **Monochrome.** Pure black canvas (`#000`), near-black surfaces (`#0A0A0A`). All hierarchy
   is a **white-on-black opacity ramp** — `#FFF → #CCC → #666` for text;
   `rgba(255,255,255,.30/.20/.12/.06)` for borders/dividers. Severity is encoded by
   **brightness, not hue** (critical = full white, archive = 10% white). The **only** hues are
   two signal accents used strictly for live status: green `#00FF00` (PASS/ONLINE) and red
   `#FF0000` (CAUTION/spike). No gradients. No brand blue/purple. No color-coded categories.
2. **Square.** `border-radius: 0` **everywhere** — corners are corners. Every border is a
   **1px white hairline**. Emphasis frames go to 2px. **No `box-shadow` anywhere** — depth is
   border + surface darkness only.
3. **Monospace only.** Two faces: **IBM Plex Mono** (interface — everything you read) and
   **Courier Prime** (machine output — IDs, code, timestamps, raw data). Hierarchy comes from
   **weight, UPPERCASE, and letter-spacing**, not size. The more official a label, the wider
   it's tracked (`.10em`–`.18em`).

**Ornament.** Every dark surface carries the **Flower of Life** SVG pattern (interlocking
circles) tiled at **5% opacity** behind content — a fixed, `pointer-events:none` watermark.
It's the one non-type brand graphic. Reuse the exact `<pattern>` from any kit's `index.html`;
do not redraw it. No photography in the dark UI.

**Motion.** Minimal and mechanical. A blinking block cursor (1s `step-end`), a 0.8s linear
spinner (1px ring, white top), bar/dot transitions at `.3s`, hover at `.12–.15s`. **No
fades-in, slides, bounces, or parallax.** Standard ease `cubic-bezier(.4,0,.2,1)`.

**Iconography.** No icon font, no SVG icon set. Icons are **Unicode geometric glyphs** in the
monospace face: `◈` brief/leads · `◻` archive · `⊹` raw signals · `▣` intel · `⊗` psyop ·
`⊡` FARA · `▷` cycle/run · `▸` list bullets · `●` live status · 45° square = status diamond.
**No emoji. No multicolor or drawn icons.** If you genuinely need a pictograph the glyph set
can't cover, use a **thin-stroke (1–1.25px) monochrome line set** (Lucide/Phosphor "thin")
white-on-black, and flag it as a substitution.

---

## Screens / Views — Console (primary surface)

App shell: a fixed **52px top header** (sticky, hairline bottom), a **210px left sidebar**,
and a scrolling `<main>` whose content maxes at **900px**. Single-page; the sidebar swaps the
active panel via local state.

### Header
- Full-width, `height:52px`, `padding:0 20px`, `background:rgba(0,0,0,.94)`, 1px bottom hairline.
- **Left:** logo lockup — a `S1` badge (1px bordered box, 10px bold, `.14em` tracking) + wordmark
  "SPEC-1 Intelligence Engine" (15px, 700, `.08em`).
- **Right:** API status — a **status diamond** (8px square rotated 45°, 1px border; filled white
  = online, hollow = offline) + label "API Live · v0.6.0" (12px, `--fg2`).

### Sidebar (`nav`, 210px)
- `background:rgba(10,10,10,.96)`, 1px right hairline, `padding:12px 0`.
- **Section labels:** 10px, 600, `.14em`, uppercase, `--fg-muted` — grouped: Intelligence ·
  Signals · Analysis · Operations. Sections after the first are preceded by a 1px divider.
- **Nav items:** 12px, `--fg-muted`, `padding:8px 16px`, `gap:8px`, a 2px transparent left border.
  Glyph in an 18px-wide centered cell. **Hover** → text to `--fg2`. **Active** → text to `--fg1`
  + left border to white. Transitions `.12s`.

### Daily Brief (`◈`)
- A single bordered panel (`rgba(10,10,10,.92)`, 1px hairline, 24px padding).
- **ID row:** a wrap of `tag` chips (11px, 1px `.30` border, `padding:2px 8px`) — date, `CONF 88%`,
  produced timestamp, and a half-opacity `brief_id`.
- **Body:** rendered from light markdown — `h1` 18px/700/`.05em`, `h2` 15px/600, `p`
  13px/`line-height:1.75`/`--fg2`, `strong` → `--fg1`, inline `code` in Courier with a 1px box.
  Trailing "Sources: …" line at 11px `--fg-muted`.

### Archive (`◻`)
- Header bar with a right-aligned **count chip** ("28 briefs"; 11px, 1px `.30` border, `padding:3px 10px`).
- A vertical stack (`gap:10px`) of clickable **brief cards** (1px `.30` border, 16–20px padding).
  Card: date (11px/600/`.1em`/white) · headline (12px/`--fg2`) · meta row (word count · CONF · id).
  **Hover** → border to full white + `rgba(255,255,255,.04)` wash. Click opens a read view with a
  ghost **← Back** button.

### Raw Signals (`⊹`) · Intel Records (`▣`) · FARA (`⊡`) — data tables
- **Filter bar:** uppercase 10px label + a 1px-bordered input/select (`background:#000`, focus →
  border to full white, no glow) + a ghost **Clear** button + a right-aligned **count chip**
  showing `N of M records`.
- **Table:** full-width, `border-collapse`. `th` 10px/600/`.1em`/uppercase/`--fg-muted` with a 1px
  `.20` bottom rule. `td` 12px/`--fg2` with a 1px `.06` bottom rule. **Row hover** → `rgba(255,255,255,.03)`.
  IDs render in Courier 10px `--fg-muted`. Long text truncates with ellipsis (`max-width:260px`).
- **Empty state:** when a filter matches nothing, a single full-width row — centered 11px uppercase
  `--fg-muted` message ("No records classified ESCALATE").
- **Confidence cell:** a 50×3px track (`rgba(255,255,255,.1)`) with a solid white fill bar + a Courier
  value (`0.82`).
- **Badges:** 10px uppercase, 1px border, no fill. Severity scales border+text opacity — critical/
  corroborated = full white, high/escalate = `.70`, medium/investigate/monitor = `.45`, low/clean =
  `.20`, archive = `.10`.

### Leads (`◈`)
- Stack of **lead cards** (1px `.25` border, `rgba(10,10,10,.9)`, 16–20px padding; hover border → `.6`).
  Header = title (13px/600) + priority badge. Summary (12px/`--fg2`/`1.65`). **Action list** — each item
  prefixed by a `▸` glyph in `rgba(255,255,255,.3)` (11px `--fg-muted`). Meta row = category badge + CONF.

### Psyop (`⊗`)
- **Analyse box:** a `state-box` (1px `.30` border) holding a label + textarea (1px border, focus →
  white, `resize:vertical`) + a **solid-border submit** button (hover → `rgba(255,255,255,.06)` wash).
  Result line shows score + risk badge + detected pattern tokens.
- **Stored scores:** cards with a risk badge + a large Courier score (20px/700) + an italic excerpt
  (`--fg-muted`) + pattern chips (10px, 1px `.15` border).

### Cycle (`▷`)
- **Stats grid:** auto-fill `minmax(140px,1fr)` boxes (1px `.25` border) — label (10px uppercase) +
  value (22px/700) + sub (10px `--fg-muted`).
- **Run box:** section heading + description + a **Run Intelligence Cycle** button. On click → a
  `running` state shows a spinner + `HARVEST → PARSE → SCORE → INVESTIGATE` + blinking cursor; resolves
  after ~2.6s to a `[OK]` done line. (In production, wire this to the real pipeline endpoint.)

---

## Interactions & behavior

- **Navigation:** sidebar click sets active panel (local state). No routing in the prototype — in
  production, map each panel to a route.
- **Filtering:** client-side, live on input/select change; **Clear** resets; count chip reflects the
  filtered total; empty result shows the empty-state row.
- **Archive:** card click → detail read view; **Back** returns to the list.
- **Cycle run:** button disables during `running` (opacity `.4`, `not-allowed`), spinner animates,
  resolves to a done message. Replace the `setTimeout` with the real async pipeline call.
- **Psyop analyse:** deterministic keyword scoring in the prototype — replace with the real scorer.
- **Hover/focus states** are defined per component above. Inputs focus to a **full-white border, no ring/glow**.
- **Political web map:** a `<canvas>` force-directed 3D graph — drag to rotate, hover to trace ties,
  click a node to pin detail; auto-orbit toggle + reset. The **district map** is real projected GIS
  (county/district polygons) with layer toggles. See `ui_kits/political/webmap.js` and `geo-pdx.js`.

## State management

Minimal, view-local in the prototype:
- `active` panel id (console shell).
- Per-panel filter inputs (`q`, classification).
- `open` archived brief (archive detail).
- `state` ∈ `idle|running|done` (cycle runner).
- Web map holds graph nodes/links + camera/orbit state internally.

In production: replace the in-file `data.js` fixtures with real data fetching
(`IntelligenceRecord` objects, signals, FARA filings, briefs). The data shapes in each kit's
`data.js` are a faithful contract for the API.

## Design Tokens

The complete, authoritative token set is in **`design-source/colors_and_type.css`** — copy it into
the target app's theme layer verbatim. Summary:

**Color**
```
--bg            #000000      canvas (always pure black)
--surface       #0A0A0A      panels / cards / nav
--surface-2     #111111      raised / hover surface
--border        #FFFFFF      the only true border color (hairline)

--fg1  #FFFFFF  --fg2 #CCCCCC  --fg3 #999999  --fg-muted #666666  --fg-faint #444444

--line-strong rgba(255,255,255,.30)   --line     rgba(255,255,255,.20)
--line-soft   rgba(255,255,255,.12)   --line-faint rgba(255,255,255,.06)
--fill-hover  rgba(255,255,255,.04)    --fill-raised rgba(255,255,255,.02)

--signal-pass  #00FF00   --signal-alert #FF0000   --signal-warn rgba(255,100,100,.9)
severity (brightness, not hue): #FFF / .70 / .45 / .20 / .10
```

**Type**
```
--font-mono  'IBM Plex Mono', 'Courier New', monospace      (interface)
--font-data  'Courier Prime', 'IBM Plex Mono', monospace     (machine output)
weights 300 / 400 / 500 / 600 / 700

scale (px): display 28 · h1 20 · h2 15 · h3 12 · body 13 · ui 12 · meta 11 · label 10 · data 10
tracking:   tight .04em · base .06em · wide .10em · wider .14em · widest .18em
line-height: tight 1.3 · ui 1.5 · body 1.75 · loose 1.8
```

**Geometry · spacing · motion**
```
--radius 0px (never round)    --border-w 1px    --border-w-2 2px    shadow: none

spacing (px): 4 · 8 · 12 · 16 · 20 · 24 · 32 · 40 · 52 · 64

--ease cubic-bezier(.4,0,.2,1)
--dur-fast .12s · --dur .15s · --dur-slow .3s · cursor blink 1s (step-end)
```

## Assets

- **Fonts:** IBM Plex Mono + Courier Prime — Google Fonts (import string is at the top of
  `colors_and_type.css`). In production, self-host for the offline/air-gapped read.
- **Flower of Life pattern:** inline SVG `<pattern>` — lift verbatim from any kit's `index.html`
  (`#fol-pattern`), render at 5% opacity, fixed, `pointer-events:none`.
- **Brand card:** `assets/spec1_social_card.png` exists in the design project (not bundled here).
- **No raster icons** — iconography is Unicode glyphs (see Design language).
- **Logo is purely typographic** — wordmark `[ SPEC-1 INTELLIGENCE ENGINE ]` + `S1` badge.

## Files in this bundle

```
design_handoff_spec1/
├── README.md                      ← this document (self-sufficient spec)
├── CLAUDE.md                      ← drop into the target repo root to prime Claude Code
├── kickoff-prompt.md              ← paste into Claude Code to start the build
├── setup.sh                       ← scaffolds a working folder + installs CLAUDE.md
└── design-source/
    ├── colors_and_type.css        ← AUTHORITATIVE design tokens (copy into theme)
    ├── DESIGN_SYSTEM.md            ← full system narrative, voice, iconography
    └── ui_kits/
        ├── console/   index.html · styles.css · components.jsx · data.js · README.md
        ├── web/       index.html · styles.css · README.md
        └── political/ index.html · styles.css · components/data/webmap/geo · README.md
```

Open any kit's `index.html` in a browser to see the live reference. Each kit's `styles.css` is
lifted from the real product source for fidelity — read it alongside this spec.

## Voice / copy (so generated strings stay on-brand)

Terminal operator meets intelligence analyst — **sober, precise, declarative.** Short sentences,
no hype, no exclamation, present tense, mechanical. UPPERCASE + tracking for labels/statuses;
`[BRACKET]` tokens for system entities; `code` for anything machine-addressable; `//` and `>>`
for log/aside lines; `::` as a namespace separator. Numbers cited flatly as proof ("607 tests").
**No emoji.** Status words: `PASS` · `CAUTION` · `ONLINE/OFFLINE` · `STABLE` · `READY` · `[OK]`.
